SETUP INSTRUCTIONS
1. Set Token in the `Token` section at the bottom of the `bot.py` file
2. Put `discord.py youtube-dl==2020.12.2 pafy ffmpeg-python asyncio` into the `Additional Packages` section of startup
3. Set Startup file to `kbbot.py` from `bot.py`
3. Boot